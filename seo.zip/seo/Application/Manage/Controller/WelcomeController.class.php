<?php
namespace Manage\Controller;
use Think\Controller;
class WelcomeController extends Controller {
    public function index(){
        $this->display();
    }
}