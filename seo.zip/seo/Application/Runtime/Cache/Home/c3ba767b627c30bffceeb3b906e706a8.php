<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <?php if(empty($id)): ?><title>
    博友彩票销售系统-提供安全可靠的彩票网站销售系统解决方案 </title>
    <meta content="彩票网站系统,移动彩票程序,彩票网站源码,彩票平台源码,彩票软件源码" name="keywords" />
    <meta name="description" content="博友彩票销售系统拥有4大核心技术解决方案,一站式为用户解决彩票网站系统、移动彩票程序的安全稳定问题。"/>
    <?php else: ?>
    <title><?php echo ($art["title"]); ?></title>
    <meta content="<?php echo ($art["writer"]); ?>" name="keywords" />
    <meta name="description" content="<?php echo ($art["des"]); ?>"/><?php endif; ?>

    <script type="text/javascript" charset="utf-8" src="/seoweb/seo/Public/js/ueditor/ueditor.config.js"></script>
    <script type="text/javascript" charset="utf-8" src="/seoweb/seo/Public/js/ueditor/ueditor.all.js"> </script>
    <script type="text/javascript" charset="utf-8" src="/seoweb/seo/Public/js/ueditor/lang/zh-cn/zh-cn.js"></script>
    <link rel="shortcut icon" href="/seoweb/seo/Public/images/favicon.ico" type="image/x-icon"/>
    <link rel="stylesheet" href="/seoweb/seo/Public/style/css/style.css">
    <link rel="stylesheet" href="/seoweb/seo/Public/style/css/index.css">
</head>

<body>
    <div class="talk">
        <a href="skype:live:boyoucaipiao?chat" target="_blank"></a>
        <a href="http://wpa.qq.com/msgrd?v=3&uin=2096586855&site=qq&menu=yes" target="_blank"></a>
        <a href="javascript:;" target="_blank"></a>
    </div>
    <div class="header">
        <div class="header-top g-width">
            <a href="/seoweb/seo/index.php?s=/Home/Index" class="logo"><img src="/seoweb/seo/Public/images/logo.png"/></a><img src="/seoweb/seo/Public/images/contact.jpg" class="contact"/>
        </div>
        <div class="header-nav">
            <div class="nav g-width">
                <ul class="nav-ul">
                    <li class="nav-li">
                        <a href="/seoweb/seo/index.php?s=/Home/Index">首页</a>
                    </li>
                    <li class="nav-li nav-active">
                        <a href="/seoweb/seo/index.php?s=/Home/ProductSolution">产品解决方案</a>
                    </li>
                    <li class="nav-li">
                        <a href="/seoweb/seo/index.php?s=/Home/ProductLiangdian">产品亮点</a>
                    </li>
                    <li class="nav-li">
                        <a href="/seoweb/seo/index.php?s=/Home/Savety">安全理念</a>
                    </li>
                    <li class="nav-li">
                        <a href="/seoweb/seo/index.php?s=/Home/News">资讯中心</a>
                    </li>
                    <li class="nav-li">
                        <a href="<?php echo U('Service/index',array('type'=>1));?>">关于博友</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="product-main cl">
        <div class="g-width main cl">
            <div class="bg"></div>
            <div class="daohang">
                <i></i>
                <a href="/seoweb/seo/index.php?s=/Home/Index">博友彩票</a>&nbsp;&nbsp;》
                <a href="/seoweb/seo/index.php?s=/Home/ProductSolution" class="active">产品解决方案</a>
            </div>
            <div class="aside">
                <dl>
                    <dt>
                        <i></i>
                        <span>产品解决方案</span>
                    </dt>
                    <dd>
                        <a href="/seoweb/seo/index.php?s=/Home/CaipiaoSys">
                            彩票网站系统
                        </a>
                    </dd>
                    <dd>
                        <a href="/seoweb/seo/index.php?s=/Home/MobileApp">
                            移动APP购彩版
                        </a>
                    </dd>
                    <dd>
                        <a href="/seoweb/seo/index.php?s=/Home/CaipiaoSolution">
                            彩票全网解决方案
                        </a>
                    </dd>
                    <dd>
                        <a href="/seoweb/seo/index.php?s=/Home/CaipiaoSource">
                            彩票源码开源合作
                        </a>
                    </dd>
                </dl>
            </div>
             <div class="product-content g-module">
                <ul>
                    <li>
                        <img src="/seoweb/seo/Public/images/icon_02.png" alt="">
                        <div class="desc-box">
                            <h5>彩票网站系统</h5>
                            <p>SLS 5.3.0彩票网站系统  语   言:  简体中文    适用企业:   大型连锁投注站业主、彩票投资企业    硬件要求:   独立服务器/独立域名（需备案） 开源授权:   允许开源授权  定制开发:   接受个性化需求定制 增值服...</p>
                            <div class="know-more">
                                <a href="/seoweb/seo/index.php?s=/Home/CaipiaoSys">了解更多&nbsp;》</a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <img src="/seoweb/seo/Public/images/icon_03.png" alt="">
                        <div class="desc-box">
                            <h5>移动APP购彩版</h5>
                            <p>SLS 5.3.0移动APP购彩版 语   言:简体中文适用企业:移动智能手机领域、平板领域投资彩票的企业硬件要求:独立服务器/独立域名（需备案）开源授权:允许开源授权定制开发:接受个性化需求定制增值服务:彩票运营基础班（6课时）、开源授权培训班...</p>
                            <div class="know-more">
                                <a href="/seoweb/seo/index.php?s=/Home/MobileApp">了解更多&nbsp;》</a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <img src="/seoweb/seo/Public/images/icon_04.png" alt="">
                        <div class="desc-box">
                            <h5>彩票全网解决方案</h5>
                            <p>博友彩票全网解决方案横跨PC、手机、APP、微信，实现彩票运营商全网覆盖，随时随地部署你的彩票系统。 　　一、PC彩票网站 　　1、官方彩票网站 　　　　SLS5.3是为网络彩票分销供应链上各个参与者提供服务的一整套系统，主要由代理商管理模块...</p>
                            <div class="know-more">
                                <a href="/seoweb/seo/index.php?s=/Home/CaipiaoSolution">了解更多&nbsp;》</a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <img src="/seoweb/seo/Public/images/icon_05.png" alt="">
                        <div class="desc-box">
                            <h5>彩票源码开源合作</h5>
                            <p>博友彩票软件的源代码基于 ASP.NET+MsSQL 开发，业务逻辑架构采用ShoveCut技术，存储过程不放在数据库中，web服务器与数据库服务器的完整分离，支持大型彩票网站项目部署时的VPN数据库同步、DNS分流；页面架构采用ReWriteUrl 技术，以及 Ajax ...</p>
                            <div class="know-more">
                                <a href="/seoweb/seo/index.php?s=/Home/CaipiaoSource">了解更多&nbsp;》</a>
                            </div>
                        </div>
                    </li>
                </ul>
               
            </div>
        </div>
    </div>
   <div class="footer">
        <div class="footer-main cl">
            <div class="yms">友情链接：</div>
            <ul class="cl">
                <?php if(is_array($links)): $i = 0; $__LIST__ = $links;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li>
                        <a href="<?php echo ($vo["link"]); ?>" target="_blank"><?php echo ($vo["title"]); ?></a>
                    </li><?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
            <p class="copy">
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Copyright  2008 - 2018博友彩票系统（shaove.com.cn）All Rights Reserved
                粤ICP备09063742号 增值电信业务经营许可 电信与信息服务业务经营许可证
            </p >
        </div>
    </div>
</body>

</html>