<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
   <title>
    博友彩票销售系统-提供安全可靠的彩票网站销售系统解决方案 </title>
    <meta content="彩票网站系统,移动彩票程序,彩票网站源码,彩票平台源码,彩票软件源码" name="keywords" />
    <meta name="description" content="博友彩票销售系统拥有4大核心技术解决方案,一站式为用户解决彩票网站系统、移动彩票程序的安全稳定问题。"/>
    <link rel="shortcut icon" href="public/images/favicon.ico" type="image/x-icon"/>
    <link rel="stylesheet" href="/seoweb/seo/Public/style/css/style.css">
    <link rel="stylesheet" href="/seoweb/seo/Public/style/css/index.css">
</head>

<body>
    <div class="talk">
        <a href="skype:live:boyoucaipiao?chat" target="_blank"></a>
        <a href="http://wpa.qq.com/msgrd?v=3&uin=2096586855&site=qq&menu=yes" target="_blank"></a>
        <a href="javascript:;" target="_blank"></a>
    </div>
   <div class="header">
        <div class="header-top g-width">
            <a href="/seoweb/seo/index.php?s=/Home/Index" class="logo"><img src="/seoweb/seo/Public/images/logo.png"/></a><img src="/seoweb/seo/Public/images/contact.jpg" class="contact"/>
        </div>
        <div class="header-nav">
            <div class="nav g-width">
                <ul class="nav-ul">
                    <li class="nav-li">
                        <a href="/seoweb/seo/index.php?s=/Home/Index">首页</a>
                    </li>
                    <li class="nav-li nav-active">
                        <a href="/seoweb/seo/index.php?s=/Home/ProductSolution">产品解决方案</a>
                    </li>
                    <li class="nav-li">
                        <a href="/seoweb/seo/index.php?s=/Home/ProductLiangdian">产品亮点</a>
                    </li>
                    <li class="nav-li">
                        <a href="/seoweb/seo/index.php?s=/Home/Savety">安全理念</a>
                    </li>
                    <li class="nav-li">
                        <a href="/seoweb/seo/index.php?s=/Home/News">资讯中心</a>
                    </li>
                    <li class="nav-li">
                        <a href="<?php echo U('Service/index',array('type'=>1));?>">关于博友</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="product-main cl">
        <div class="g-width main cl">
            <div class="bg"></div>
            <div class="daohang">
                <i></i>
                <a href="/seoweb/seo/index.php?s=/Home/Index">博友彩票</a>&nbsp;&nbsp;》
                <a href="/seoweb/seo/index.php?s=/Home/ProductSolution">产品解决方案</a>&nbsp;&nbsp;》
                <a href="/seoweb/seo/index.php?s=/HomeMobileApp" class="active">移动APP购彩版</a>
            </div>
            <div class="aside">
                <dl>
                    <dt>
                        <i></i>
                        <span>产品解决方案</span>
                    </dt>
                    <dd>
                        <a href="/seoweb/seo/index.php?s=/Home/CaipiaoSys">
                            彩票网站系统
                        </a>
                    </dd>
                    <dd class="active">
                        <a href="/seoweb/seo/index.php?s=/Home/MobileApp" class="active">
                            移动APP购彩版
                        </a>
                    </dd>
                    <dd>
                        <a href="/seoweb/seo/index.php?s=/Home/CaipiaoSolution">
                            彩票全网解决方案
                        </a>
                    </dd>
                    <dd>
                        <a href="/seoweb/seo/index.php?s=/Home/CaipiaoSource">
                            彩票源码开源合作
                        </a>
                    </dd>
                </dl>
            </div>
            <div class="mobile-content g-module">
                <div class="floor-1">
                    <h4>
                        SLS 5.3.0移动APP购彩版
                    </h4>
                    <table>
                        <tr>
                            <td>语   言:</td>
                            <td>简体中文</td>
                        </tr>
                        <tr>
                            <td>适用企业:</td>
                            <td>移动智能手机领域、平板领域投资彩票的企业</td>
                        </tr>
                        <tr>
                            <td>硬件要求:</td>
                            <td>独立服务器/独立域名（需备案）</td>
                        </tr>
                        <tr>
                            <td>开源授权:</td>
                            <td>允许开源授权</td>
                        </tr>
                        <tr>
                            <td>定制开发:</td>
                            <td>接受个性化需求定制</td>
                        </tr>
                        <tr>
                            <td>增值服务:</td>
                            <td>彩票运营基础班（6课时）、开源授权培训班（9课时）</td>
                        </tr>
                    </table>
                </div>
                <div class="floor-2">
                    <h4>
                        产品截图
                    </h4>
                    <div class="img-box cl">
                        <img src="/seoweb/seo/Public/images/pic1.png" alt="">
                        <img src="/seoweb/seo/Public/images/pic2.png" alt="">
                        <img src="/seoweb/seo/Public/images/pic3.png" alt="">
                    </div>
                </div>
                <div class="floor-3">
                    <h4>
                        产品功能列表
                    </h4>
                    <table>
                        <tr>
                            <th>主要板块</th>
                            <th>子功能模板</th>
                            <th>子功能详细描述</th>
                        </tr>
                        <tr>
                            <td class="font-color center" rowspan="4">代购合买板块</td>
                            <td>代购</td>
                            <td class="padding30">简洁明细的投注页面，支持自选、摇一摇机选、胆拖选号投注方式。</td>
                        </tr>
                        <tr>
                            <td>合买</td>
                            <td class="padding30">发起合买，设置合买参数，发起合买方案，让大家一起购买，投注号码多，减少投注风险，提高中奖率；参与合买，对网站的未满员的方案进行筛选，选择合适的方案参与合买，中奖奖金根据合买的股份自动分配。</td>
                        </tr>
                        <tr>
                            <td>方案保底</td>
                            <td class="padding30">会员发起合买方案时，可以选择保底功能。这样，当方案认购时间截止时，如果方案还没有满员，系统将自动用会员的保底金额，对方案进行自动认购，最大限度的确保方案的满员合买成功。</td>
                        </tr>
                        <tr>
                            <td>追号投注</td>
                            <td class="padding30">设置追号参数，多期投注一次完成。追号投注发起后，系统将自动冻结完成全部投注所需的最大资金。追号过程中，系统将按设定的投注要求连续为自动购买所选择的号码及玩法。</td>
                        </tr>
                        <tr>
                            <td class="font-color center" rowspan="10">个人中心</td>
                            <td>资料管理</td>
                            <td class="padding30">可以对注册提交的资料进行补充说明及修改。如个人基本资料、银行资料。</td>
                        </tr>
                        <tr>
                            <td>登陆</td>
                            <td class="padding30">实现客户端的登陆，与网站ID相同。</td>
                        </tr>
                        <tr>
                            <td>免费注册</td>
                            <td class="padding30">注册新用户。</td>
                        </tr>
                        <tr>
                            <td>账户明细</td>
                            <td class="padding30">可以对自己的账户情况作全方面的了解，如账户余额、冻结资金、可投注余额。可以通过数据库检索，全面了解前期账户收入支出情况，作出合理分析。</td>
                        </tr>
                        <tr>
                            <td>网上支付</td>
                            <td class="padding30">会员通过网上银行在线支付平台转款后，预付款即时转入会员在网站的账户中，可以立即参与合买和代购，不需要管理员手动向用户账户进行添加预付款的操作。推荐在线支付用支付宝等第三方支付平台</td>
                        </tr>
                        <tr>
                            <td>提取现金</td>
                            <td class="padding30">提交提取账户现金的请求后，一个工作日内网站管理员通过在线转账的方式把提取金额转至彩民的指定账户。</td>
                        </tr>
                        <tr>
                            <td>全部彩票</td>
                            <td class="padding30">查询检索会员个人的所有合买、自购、追号历史投注信息。</td>
                        </tr>
                        <tr>
                            <td>中奖查询</td>
                            <td class="padding30">查看会员自己的所有中奖记录，促进二次购买。</td>
                        </tr>
                        <tr>
                            <td>合买记录</td>
                            <td class="padding30">查看会员自己的所有发起合买记录。</td>
                        </tr>
                        <tr>
                            <td>追号记录</td>
                            <td class="padding30">查询检索会员账户交易清单。</td>
                        </tr>
                        <tr>
                            <td class="font-color center">开奖公告</td>
                            <td>中奖查询</td>
                            <td class="padding30">处理会员提交反馈的各种问题，增进客户的忠诚度和粘着度。可以列表出全部问题、已处理问题、未处理问题等。</td>
                        </tr>
                        <tr>
                            <td class="font-color center" rowspan="3">新闻资讯</td>
                            <td>专家推荐</td>
                            <td rowspan="3" class="padding30">即时发布各种新闻信息资讯（如综合要闻、中奖花絮、说票论彩、媒体追踪、足球资讯等栏目）。新闻可自由多级分类，发布文字新闻、图片新闻，数据与移动端通用。</td>
                        </tr>
                        <tr>
                            <td>彩票资讯</td>
                        </tr>
                        <tr>
                            <td>站点公告</td>
                        </tr>
                        <tr>
                            <td class="font-color center">合买大厅</td>
                            <td colspan="2">可以选择彩种，对未满员的方案进行筛选，选择合适的方案参与合买，中奖奖金根据合买的股份自动分配。</td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="footer">
        <div class="footer-main cl">
            <div class="yms">友情链接：</div>
            <ul class="cl">
                <?php if(is_array($links)): $i = 0; $__LIST__ = $links;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li>
                        <a href="<?php echo ($vo["link"]); ?>" target="_blank"><?php echo ($vo["title"]); ?></a>
                    </li><?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
            <p class="copy">
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Copyright  2008 - 2018博友彩票系统（shaove.com.cn）All Rights Reserved
                粤ICP备09063742号 增值电信业务经营许可 电信与信息服务业务经营许可证
            </p >
        </div>
    </div>
</body>

</html>