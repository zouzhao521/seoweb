<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <title>
   博友彩票销售系统-技术客服24小时诚意为客户服务,解决问题</title>
    <meta content="
    彩票aPP开发,彩票源码" name="keywords" />
    <meta name="description" content="博友彩票销售系统拥有一批优质技术客服，以解决用户问题为宗旨，全天24小时针对客户的问题提供一对一的针对性服务。"/>
    <link rel="shortcut icon" href="/seoweb/seo/Public/images/favicon.ico" type="image/x-icon"/>
    <link rel="stylesheet" href="/seoweb/seo/Public/style/css/style.css">
    <link rel="stylesheet" href="/seoweb/seo/Public/style/css/index.css">
</head>

<body>
    <div class="talk">
        <a href="skype:live:boyoucaipiao?chat" target="_blank"></a>
        <a href="http://wpa.qq.com/msgrd?v=3&uin=2096586855&site=qq&menu=yes" target="_blank"></a>
        <a href="javascript:;" target="_blank"></a>
    </div>
   <div class="header">
        <div class="header-top g-width">
            <a href="/seoweb/seo/index.php?s=/Home/Index" class="logo"><img src="/seoweb/seo/Public/images/logo.png"/></a><img src="/seoweb/seo/Public/images/contact.jpg" class="contact"/>
        </div>
        <div class="header-nav">
            <div class="nav g-width">
                <ul class="nav-ul">
                    <li class="nav-li">
                        <a href="/seoweb/seo/index.php?s=/Home/Index">首页</a>
                    </li>
                    <li class="nav-li">
                        <a href="/seoweb/seo/index.php?s=/Home/ProductSolution">产品解决方案</a>
                    </li>
                    <li class="nav-li">
                        <a href="/seoweb/seo/index.php?s=/Home/ProductLiangdian">产品亮点</a>
                    </li>
                    <li class="nav-li">
                        <a href="/seoweb/seo/index.php?s=/Home/Savety">安全理念</a>
                    </li>
                    <li class="nav-li">
                        <a href="/seoweb/seo/index.php?s=/Home/News">资讯中心</a>
                    </li>
                    <li class="nav-li nav-active">
                        <a href="<?php echo U('Service/index',array('type'=>1));?>">关于博友</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="product-main cl sevice">
        <div class="g-width main cl">
            <div class="bg"></div>
            <div class="daohang">
                <i></i>
                <a href="/seoweb/seo/index.php?s=/Home/Index">博友彩票</a>&nbsp;&nbsp;》
                <a href="<?php echo U('Service/index',array('type'=>1));?>" class="active">关于博友</a>
            </div>
            <div class="aside">
                <dl>
                    <dt>
                        <i></i>
                        <span>关于博友</span>
                    </dt>
                    <dd <?php if($type == 1): ?>class='active'<?php endif; ?>>
                        <a href="<?php echo U('Service/index',array('type'=>1));?>">
                            公司简介
                        </a>
                    </dd>
                    <dd <?php if($type == 2): ?>class='active'<?php endif; ?>>
                        <a href="<?php echo U('Service/index',array('type'=>2));?>">
                            售后服务
                        </a>
                    </dd>
                    <dd <?php if($type == 3): ?>class='active'<?php endif; ?>>
                        <a href="<?php echo U('Service/index',array('type'=>3));?>">
                            联系博友
                        </a>
                    </dd>
                </dl>
            </div>
            <?php if($type == 2): ?><div class="sevice-content g-module">
                <h4>
                    售后服务范围
                    <span>(包含工单数换算标准)</span>
                </h4>
                <ul class="sev-ul cl">
                    <li>
                        <div class="number-box">
                            <div class="number">01</div>
                        </div>
                        <p class="zhuti">
                            <span></span>软件同版本内免费升级</p>
                        <p class="desc">每次工单4个</p>
                    </li>
                    <li>
                        <div class="number-box">
                            <div class="number">02</div>
                        </div>
                        <p class="zhuti">
                            <span></span>APP、网页文字内容修改</p>
                        <p class="desc">每次为1个工单</p>
                    </li>
                    <li>
                        <div class="number-box">
                            <div class="number">03</div>
                        </div>
                        <p class="zhuti">
                            <span></span>删除网页</p>
                        <p class="desc">每次1个工单</p>
                    </li>
                    <li>
                        <div class="number-box">
                            <div class="number">04</div>
                        </div>
                        <p class="zhuti">
                            <span></span>域名管理解析</p>
                        <p class="desc">每次为工单1个</p>
                    </li>
                    <li>
                        <div class="number-box">
                            <div class="number">05</div>
                        </div>
                        <p class="zhuti">
                            <span></span>APP数据备份杀毒</p>
                        <p class="desc">每次为1个工单</p>
                    </li>
                    <li>
                        <div class="number-box">
                            <div class="number">06</div>
                        </div>
                        <p class="zhuti">
                            <span></span>协助处理黑客攻击</p>
                        <p class="desc">每次为1个工单</p>
                    </li>
                    <li>
                        <div class="number-box">
                            <div class="number">07</div>
                        </div>
                        <p class="zhuti">
                            <span></span>处理产品图片</p>
                        <p class="desc">免费100张后开始记工单，
                            <br>每1张为1个工单</p>
                    </li>
                    <li>
                        <div class="number-box">
                            <div class="number">08</div>
                        </div>
                        <p class="zhuti">
                            <span></span>制作手机Html5广告条、
                            <br>&nbsp;FLASH广告条(800*200)</p>
                        <p class="desc">每次工单4个</p>
                    </li>
                    <li>
                        <div class="number-box">
                            <div class="number">09</div>
                        </div>
                        <p class="zhuti">
                            <span></span>制作浮动广告</p>
                        <p class="desc">每个广告为6个单位</p>
                    </li>
                    <li>
                        <div class="number-box">
                            <div class="number">10</div>
                        </div>
                        <p class="zhuti">
                            <span></span>添加产品信息</p>
                        <p class="desc">每条为1个工单</p>
                    </li>
                    <li>
                        <div class="number-box">
                            <div class="number">11</div>
                        </div>
                        <p class="zhuti">
                            <span></span>添加新闻资讯/公司简介</p>
                        <p class="desc">每条为1个工单</p>
                    </li>
                    <li>
                        <div class="number-box">
                            <div class="number">12</div>
                        </div>
                        <p class="zhuti">
                            <span></span>网站转移部署</p>
                        <p class="desc">每条为1个工单</p>
                    </li>
                    <li>
                        <div class="number-box">
                            <div class="number">13</div>
                        </div>
                        <p class="zhuti">
                            <span></span>ICP备案</p>
                        <p class="desc">每备案一个域名为4个工单</p>
                    </li>
                    <li>
                        <div class="number-box">
                            <div class="number">14</div>
                        </div>
                        <p class="zhuti">
                            <span></span>APP安卓应用商店发布、
                            <br/>&nbsp;苹果应用商店发布</p>
                        <p class="desc">15个工单</p>
                    </li>
                    <li>
                        <div class="number-box">
                            <div class="number">15</div>
                        </div>
                        <p class="zhuti">
                            <span></span>苹果应用商店企业账号
                            <br/>&nbsp;协助申请</p>
                        <p class="desc">12个工单</p>
                    </li>
                    <li>
                        <div class="number-box">
                            <div class="number">16</div>
                        </div>
                        <p class="zhuti">
                            <span></span>微信公众号服务号协助
                            <br>&nbsp;认证</p>
                        <p class="desc">20个工单</p>
                    </li>
                </ul>
                <h4>
                    工单制及工单号
                </h4>
                <div class="gd cl">
                    <p class="gd-title">工单制</p>
                    <p class="gd-content">我们所有的产品售后问题都以工单的形式进行提交，每一个问题都会获得一个工单编号。客户可以通过工单编号追踪售后问题的处理进度，同时对处理结果进行评价，以提升我们的售后服务质量。</p>
                </div>
                <div class="gd cl">
                    <p class="gd-title">工单数</p>
                    <p class="gd-content">我们把每1小时的工作量计为一个工单数。客户在提交了售后问题工单后，我们就会立即进行问题处理，同时会消耗客户一定的工单数。首年客户，我们都会免费赠送铜牌工单维护包（包含60个工单数）。</p>
                </div>
            <?php elseif($type == 1): ?>
                <div class="profile-content g-module">
                    <span>公司简介</span><br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;博友彩票系统专注于彩票系统的开发与研究，公司服务于金融机构、彩票机构、上市公司量身定做互联网彩票系统的整体方案，公司秉承“帮助用户成功”的经营理念，在产品研发方面敢于创新、遵循市场规律、以过硬的技术和一流的服务赢得了市场的认可和客户的满意。以规范、创新、服务至上的理念，促进互联网彩票的良性发展。<br/><br/>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;博友彩票系统历时9年的迭代开发，拥有最专业的彩票软件开发团队，一直致力于“行业信息化”这一品牌使命。从前期的需求调研、开发管理、售后服务三大环节保障客户的每一个产品的成功。现已覆盖全国，为全国近4000多家行业企业提供信息化及电子商务解决方案。<br/><br/>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;博友期待与您合作，您的信任是博友彩票销售系统不懈努力的目标，博友彩票系统以“满足不同客户的不同需求”为准则，秉承“帮助用户成功”的经营理念，与全球企业一起共同成长，博友期待与您共创美好未来！<br/><br/>

<span>彩票系统产品</span><br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;公司目前拥有彩票网站系统、移动APP购彩版、彩票全网解决方案、彩票源码开源合作等产品解决方案，量身打造互联网彩票产品方案以及互联网彩票在线系统、移动购彩系统。 <br/><br/>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;企业购买博友彩票系统后通过快速部署便能上线企业彩票网站、彩票APP、彩票客户端，以快速在互联网上展开彩票战略部署！
                </div>
            <?php elseif($type == 3): ?>
                <div class="contact-content g-module">
                    <img src="/seoweb/seo/Public/images/contact_us.jpg">
                </div><?php endif; ?>
            </div>
        </div>
    </div>
    <div class="footer">
        <div class="footer-main cl">
            <div class="yms">友情链接：</div>
            <ul class="cl">
                <?php if(is_array($links)): $i = 0; $__LIST__ = $links;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li>
                        <a href="<?php echo ($vo["link"]); ?>" target="_blank"><?php echo ($vo["title"]); ?></a>
                    </li><?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
            <p class="copy">
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Copyright  2008 - 2018博友彩票系统（shaove.com.cn）All Rights Reserved
                粤ICP备09063742号 增值电信业务经营许可 电信与信息服务业务经营许可证
            </p >

        </div>
    </div>
</body>

</html>