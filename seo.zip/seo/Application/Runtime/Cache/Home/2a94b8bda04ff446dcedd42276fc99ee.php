<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <title><?php echo ($website["title"]); ?></title>
    <meta content="<?php echo ($website["key"]); ?>" name="keywords" />
    <meta name="description" content="<?php echo ($website["des"]); ?>"/>
    <link rel="shortcut icon" href="/seoweb/seo/Public/images/favicon.ico" type="image/x-icon"/>
    <link rel="stylesheet" href="/seoweb/seo/Public/style/css/style.css" />
    <link rel="stylesheet" href="/seoweb/seo/Public/style/css/index.css" />
    <link rel="stylesheet" href="/seoweb/seo/Public/lib/style/swiper-4.1.6.min.css" />
</head>

<body>
    <div class="talk">
        <a href="skype:live:boyoucaipiao?chat" target="_blank"></a>
        <a href="http://wpa.qq.com/msgrd?v=3&uin=2096586855&site=qq&menu=yes" target="_blank"></a>
        <a href="javascript:;" target="_blank"></a>
    </div>
    <div class="header">
        <div class="header-top g-width">
            <a href="/seoweb/seo/index.php?s=/Home/Index" class="logo"><img src="/seoweb/seo/Public/images/logo.png"/></a><img src="/seoweb/seo/Public/images/contact.jpg" class="contact"/>
        </div>
        <div class="header-nav">
            <div class="nav g-width">
                <ul class="nav-ul">
                    <li class="nav-li nav-active">
                        <a href="/seoweb/seo/index.php?s=/Home/Index">首页</a>
                    </li>
                    <li class="nav-li">
                        <a href="/seoweb/seo/index.php?s=/Home/ProductSolution">产品解决方案</a>
                    </li>
                    <li class="nav-li">
                        <a href="/seoweb/seo/index.php?s=/Home/ProductLiangdian">产品亮点</a>
                    </li>
                    <li class="nav-li">
                        <a href="/seoweb/seo/index.php?s=/Home/Savety">安全理念</a>
                    </li>
                    <li class="nav-li">
                        <a href="/seoweb/seo/index.php?s=/Home/News">资讯中心</a>
                    </li>
                    <li class="nav-li">
                        <a href="<?php echo U('Service/index',array('type'=>1));?>">关于博友</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="index-banner">
        <div class="banner">
            <div class='swiper-container '>
                <div class='swiper-wrapper'>
                    <div class='swiper-slide swiper-no-swiping'>
                        <a href='javascript:;'>
                            <img src="/seoweb/seo/Public/images/index_banner1.png" />
                        </a>
                    </div>
                    <div class='swiper-slide swiper-no-swiping'>
                        <a href='javascript:;'>
                            <img src="/seoweb/seo/Public/images/index_banner2.png" />
                        </a>
                    </div>
                    <div class='swiper-slide swiper-no-swiping'>
                        <a href='javascript:;'>
                            <img src="/seoweb/seo/Public/images/index_banner3.png" />
                        </a>
                    </div>
                    <div class='swiper-slide swiper-no-swiping'>
                        <a href='javascript:;'>
                            <img src="/seoweb/seo/Public/images/index_banner4.png" />
                        </a>
                    </div>
                </div>
                <div class='swiper-button-prev'></div>
                <div class='swiper-button-next'></div>
                <div class='swiper-pagination swiper-no-swiping'></div>
            </div>
        </div>
        <div class="banner-bottom">
            <div class="bg">
                <div class="g-width b-content">
                    <h1>中国极具影响力的彩票销售系统服务商！</h1>
                    <p class="l-title">DO MORE DO BEST</p>
                    <p class="b-detail">博友彩票系统专注于彩票系统的开发与研究,亦是致力于“行业信息化”这一品牌使命，拥有互联网彩票系统开发多年行业经验，实现为客户量身定制整体解决方案、互联网彩票产品方案以及互联网彩票在线系统、移动购彩系统方案等。深受合作伙伴的信任，得到大家的一致好评。</p>
                </div>
            </div>
        </div>
    </div>
    <div class="index-main">
        <div class="g-width main">
            <h2>
                我们的优势
            </h2>
            <div class="line-box">
                <div class="juxing"></div>
            </div>
            <div class="miaoshu">
                <p>博友拥有十年的软件开发精英团队,从前期的需求调研、开发管理、售后服务三大环节,以“客户满意度、体验度、简单上手”为标准,多年来不断探索整合市场需求并加以创新,满足客户的多元化需求。</p>
            </div>
            <div class="project">
                <ul class="pro-ul">
                    <li class="pro-li">
                        <a href="/seoweb/seo/index.php?s=/Home/CaipiaoSys" target="_blank">
                            <img src="/seoweb/seo/Public/images/icon01_weixuanzhong.png" alt="">
                            <div class="desc-box">
                                <h3>
                                    彩票网站系统
                                </h3>
                                <p class="icon-list-1 icon-list">
                                    <i num = 1></i>
                                    <i num = 2></i>
                                    <i num = 3></i>
                                </p>
                                <p class="desc">
                                    SLS 5.3 是一款及多重营销功能
                                    <br/> 与一体的互联网彩票销售系统....
                                </p>
                            </div>
                        </a>
                    </li>
                    <li class="pro-li">
                        <a href="/seoweb/seo/index.php?s=/Home/MobileApp" target="_blank">
                            <img src="/seoweb/seo/Public/images/icon02_weixuanzhong.png" alt="">
                            <div class="desc-box">
                                <h3>
                                    移动APP购彩版
                                </h3>
                                <p class="icon-list-2 icon-list">
                                    <i num = 4></i>
                                    <i num = 5></i>
                                    <i num = 6></i>
                                </p>
                                <p class="desc">
                                    SLS 5.3.0移动APP购彩版
                                    <br/> 语言:简体中文适 用企业:....
                                </p>
                            </div>
                        </a>
                    </li>
                    <li class="pro-li">
                        <a href="/seoweb/seo/index.php?s=/Home/CaipiaoSolution" target="_blank">
                            <img src="/seoweb/seo/Public/images/icon03_weixuanzhong.png" alt="">
                            <div class="desc-box">
                                <h3>
                                    彩票全网解决方案
                                </h3>
                                <p class="icon-list-3 icon-list">
                                    <i num = 7></i>
                                    <i num = 8></i>
                                    <i num = 9></i>
                                </p>
                                <p class="desc">
                                    博友彩票全网解决方案横跨PC、手机、
                                    <br/> APP、微信，实现彩....
                                </p>
                            </div>
                        </a>
                    </li>
                    <li class="pro-li">
                        <a href="/seoweb/seo/index.php?s=/Home/CaipiaoSource" target="_blank">
                            <img src="/seoweb/seo/Public/images/icon04_weixuanzhong.png" alt="">
                            <div class="desc-box">
                                <h3>
                                    彩票源码开源合作
                                </h3>
                                <p class="icon-list-4 icon-list">
                                    <i num = 10></i>
                                    <i num = 11></i>
                                    <i num = 12></i>
                                </p>
                                <p class="desc">
                                    博友彩票软件的源代码基于 
                                    <br/> ASP.NET+MsSQL 开发，业务逻....
                                </p>
                            </div>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="news-tab">
                <div class="news">
                    <div class="title-box">
                        <p class="b-title">产品资讯<span>NEWS</span></p>
                        <p class="l-title">声音·观点</p>
                        <a class="news-more" href="<?php echo U('News/index',array('type'=>$types[0]['id']));?>" target="_blank">MORE ></a>
                    </div>
                    <?php if(is_array($articles_1)): $i = 0; $__LIST__ = $articles_1;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="info-content">
                            <div class="img-box">
                                <img src="/seoweb/seo/Public/Uploads/<?php echo ($vo["img"]); ?>">
                            </div>
                            <div class="detail-box">
                                <div class="c-title">
                                    <a href="<?php echo U('News/index',array('id'=>$vo['id']));?>" target="_blank"><?php echo ($vo["title"]); ?></a>
                                </div>
                                <div class="desc">
                                    <?php echo ($vo["des"]); ?>
                                </div> 
                            </div>
                        </div><?php endforeach; endif; else: echo "" ;endif; ?>
                </div>
                <div class="news">
                    <div class="title-box">
                        <p class="b-title">行业新闻<span>NEWS</span></p>
                        <p class="l-title">声音·观点</p>
                        <a class="news-more" href="<?php echo U('News/index',array('type'=>$types[1]['id']));?>" target="_blank">MORE ></a>
                    </div>
                    <?php if(is_array($articles_2)): $i = 0; $__LIST__ = $articles_2;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="info-content">
                            <div class="img-box">
                                <img src="/seoweb/seo/Public/Uploads/<?php echo ($vo["img"]); ?>">
                            </div>
                            <div class="detail-box">
                                <div class="c-title">
                                    <a href="<?php echo U('News/index',array('id'=>$vo['id']));?>" target="_blank"><?php echo ($vo["title"]); ?></a>
                                </div>
                                <div class="desc">
                                    <?php echo ($vo["des"]); ?>
                                </div> 
                            </div>
                        </div><?php endforeach; endif; else: echo "" ;endif; ?>
                </div>
            </div>
            <div class="company">
                <h2>
                    选择博友,值得信赖
                </h2>
                <div class="line-box">
                    <div class="juxing"></div>
                </div>
                <div class="miaoshu">
                    <p>博友彩票系统历时9年的迭代开发,累计服务了900多家大型企业的互联网彩票销售平台,完成累计600多亿交易额。</p>
                </div>
                <ul class="workmate cl">
                    <li>
                        <img src="/seoweb/seo/Public/images/LOGO_01.png" alt="">
                    </li>
                    <li>
                        <img src="/seoweb/seo/Public/images/LOGO_02.png" alt="">
                    </li>
                    <li>
                        <img src="/seoweb/seo/Public/images/LOGO_03.png" alt="">
                    </li>
                    <li>
                        <img src="/seoweb/seo/Public/images/LOGO_04.png" alt="">
                    </li>
                    <li>
                        <img src="/seoweb/seo/Public/images/LOGO_05.png" alt="">
                    </li>
                    <li>
                        <img src="/seoweb/seo/Public/images/LOGO_06.png" alt="">
                    </li>
                    <li>
                        <img src="/seoweb/seo/Public/images/LOGO_07.png" alt="">
                    </li>
                    <li>
                        <img src="/seoweb/seo/Public/images/LOGO_08.png" alt="">
                    </li>
                    <li>
                        <img src="/seoweb/seo/Public/images/LOGO_09.png" alt="">
                    </li>
                    <li>
                        <img src="/seoweb/seo/Public/images/LOGO_10.png" alt="">
                    </li>
                    <li>
                        <img src="/seoweb/seo/Public/images/LOGO_11.png" alt="">
                    </li>
                    <li>
                        <img src="/seoweb/seo/Public/images/LOGO_12.png" alt="">
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="footer">
        <div class="footer-main cl">
            <div class="yms">友情链接：</div>
            <ul class="cl">
                <?php if(is_array($links)): $i = 0; $__LIST__ = $links;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li>
                        <a href="<?php echo ($vo["link"]); ?>" target="_blank"><?php echo ($vo["title"]); ?></a>
                    </li><?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
            <p class="copy">
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Copyright  2008 - 2018博友彩票系统（shaove.com.cn）All Rights Reserved
                粤ICP备09063742号 增值电信业务经营许可 电信与信息服务业务经营许可证
            </p >
        </div>
    </div>
    <script src="/seoweb/seo/Public/lib/js/jquery-1.11.3.js"></script>
    <script src="/seoweb/seo/Public/lib/js/swiper-4.1.6.min.js"></script>
    <script src="/seoweb/seo/Public/js/swiper.js"></script>
    <script>
        var proLi = $(".pro-li");

        proLi.on("mouseenter", function (e) {
            for (var i = 0; i < $(".pro-li").length; i++) {
                $(".pro-li").eq(i).removeClass("active").find("img").attr("src", "/seoweb/seo/Public/images/icon0" + (i + 1) + "_weixuanzhong.png");
            };
            $(this).addClass("active").find("img").attr("src", "/seoweb/seo/Public/images/icon0" + ($(this).index() + 1) + "_xuanzhong.png");
            var num = $(this).index() + 1;
            $(this).find(".icon-list i").each(function (index, ele) {
                $(ele).css("background", "url(/seoweb/seo/Public/images/small-icon_0" + $(ele).attr("num") + "_xuanzhong.png) 8px 0 no-repeat")
            })
            $(this).find(".desc-box .desc").eq(0).fadeIn(500);
        })

        proLi.on("mouseleave", function () {
            var num = $(this).index() + 1;
            $(this).removeClass("active").find("img").attr("src", "/seoweb/seo/Public/images/icon0" + ($(this).index() + 1) + "_weixuanzhong.png");
            $(this).find(".icon-list i").each(function (index, ele) {
                $(ele).css("background", "url(/seoweb/seo/Public/images/small-icon_0" + $(ele).attr("num") + "_weixuanzhong.png) 8px 0 no-repeat")
            })
            $(this).find(".desc-box .desc").eq(0).fadeOut(500);
        })


    </script>
</body>

</html>