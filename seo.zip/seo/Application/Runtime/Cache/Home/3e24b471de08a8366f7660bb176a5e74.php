<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <?php if(empty($id)): ?><title>
    博友彩票销售系统-提供全方位的彩票网站建设资讯和行业最新彩票新闻 </title>
    <meta content="彩票网站建设,彩票网站制作,彩票投注软件" name="keywords" />
    <meta name="description" content="彩票软件哪个好，博友彩票销售系统专注行业发展趋势，实时更新发布最新资讯动态，为用户提供提供全方位的学习渠道。"/>
    <?php else: ?>
    <title><?php echo ($art["title"]); ?></title>
    <meta content="<?php echo ($art["writer"]); ?>" name="keywords" />
    <meta name="description" content="<?php echo ($art["des"]); ?>"/><?php endif; ?>

    <script type="text/javascript" charset="utf-8" src="/seoweb/seo/Public/js/ueditor/ueditor.config.js"></script>
    <script type="text/javascript" charset="utf-8" src="/seoweb/seo/Public/js/ueditor/ueditor.all.js"> </script>
    <script type="text/javascript" charset="utf-8" src="/seoweb/seo/Public/js/ueditor/lang/zh-cn/zh-cn.js"></script>
    <link rel="shortcut icon" href="/seoweb/seo/Public/images/favicon.ico" type="image/x-icon"/>
    <link rel="stylesheet" href="/seoweb/seo/Public/style/css/style.css">
    <link rel="stylesheet" href="/seoweb/seo/Public/style/css/index.css">
</head>

<body>
    <div class="talk">
        <a href="skype:live:boyoucaipiao?chat" target="_blank"></a>
        <a href="http://wpa.qq.com/msgrd?v=3&uin=2096586855&site=qq&menu=yes" target="_blank"></a>
        <a href="javascript:;" target="_blank"></a>
    </div>
    <div class="header">
        <div class="header-top g-width">
            <a href="/seoweb/seo/index.php?s=/Home/Index" class="logo"><img src="/seoweb/seo/Public/images/logo.png"/></a><img src="/seoweb/seo/Public/images/contact.jpg" class="contact"/> 
        </div>
        <div class="header-nav">
            <div class="nav g-width">
                <ul class="nav-ul">
                    <li class="nav-li">
                        <a href="/seoweb/seo/index.php?s=/Home/Index">首页</a>
                    </li>
                    <li class="nav-li">
                        <a href="/seoweb/seo/index.php?s=/Home/ProductSolution">产品解决方案</a>
                    </li>
                    <li class="nav-li">
                        <a href="/seoweb/seo/index.php?s=/Home/ProductLiangdian">产品亮点</a>
                    </li>
                    <li class="nav-li">
                        <a href="/seoweb/seo/index.php?s=/Home/Savety">安全理念</a>
                    </li>
                     <li class="nav-li nav-active">
                        <a href="/seoweb/seo/index.php?s=/Home/News">资讯中心</a>
                    </li>
                    <li class="nav-li">
                        <a href="<?php echo U('Service/index',array('type'=>1));?>">关于博友</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="product-main cl zixun">
        <div class="g-width main cl">
            <div class="bg"></div>
            <div class="daohang">
                <i></i>
                <a href="/seoweb/seo/index.php?s=/Home/Index">博友彩票</a>&nbsp;&nbsp;》
                <a href="/seoweb/seo/index.php?s=/Home/News">资讯中心</a>
                <a href="<?php echo U('News/index',array('type'=>$type));?>" class="active">&nbsp;&nbsp;》<?php echo ($title['type']); ?></a>
            </div>
            <div class="aside">
                <dl>
                    <dt>
                        <i></i>
                        <span>资讯中心</span>
                    </dt>
                    <?php if(is_array($types)): $i = 0; $__LIST__ = $types;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><dd <?php if($vo['id'] == $type): ?>class='active'<?php endif; ?>>
                        <a href="<?php echo U('News/index',array('type'=>$vo['id']));?>" >
                            <?php echo ($vo["type"]); ?>
                        </a>
                    </dd><?php endforeach; endif; else: echo "" ;endif; ?>
                </dl>
            </div>
            <div class="news-content g-module">
            <?php if(empty($id)): ?><ul>
                <?php if(is_array($articles)): $i = 0; $__LIST__ = $articles;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li>
                        <img src="/seoweb/seo/Public/Uploads/<?php echo ($vo["img"]); ?>" alt="">
                        <div class="desc-box">
                            <h5><a href="<?php echo U('News/index',array('id'=>$vo['id']));?>" target="_blank"><?php echo ($vo["title"]); ?></a></h5>
                            <p><?php echo ($vo["des"]); ?></p>
                            <!-- <div class="know-more">
                                <a href="<?php echo U('News/index',array('id'=>$vo['id']));?>" target="_blank">了解更多&nbsp;》</a>
                            </div> -->
                        </div>
                    </li><?php endforeach; endif; else: echo "" ;endif; ?> 
                </ul>
            <?php else: ?>
            <div class="article-title">
                <div style="color:#000;font-size:16px;"><?php echo ($art["title"]); ?></div>
                <div style="margin-top:15px;"><?php echo ($art["time"]); ?></div>
            </div>
            <?php echo ($art["content"]); endif; ?>
            <?php if(empty($id)): ?><div class="fenye-box">
                    <a href="<?php echo U('News/index',array('type'=>$type,'pa'=>0,'page'=>$pagesize));?>" class="firstpage-btn">首页</a>
                    <a href="<?php echo U('News/index',array('type'=>$type,'pa'=>$pa-1,'page'=>$pagesize));?>" class="prev-btn">上一页</a>
                    <a href="<?php echo U('News/index',array('type'=>$type,'pa'=>$pa+1,'page'=>$pagesize));?>" class="next-btn">下一页</a>
                    <a href="<?php echo U('News/index',array('type'=>$type,'pa'=>$pagesize,'page'=>$pagesize));?>" class="lastpage-btn">尾页</a>        
                </div>
            <?php else: ?>
                <div class="pageview">
                    <?php if(empty($art2)): ?><a>下一篇：没有上一篇</a><?php else: ?><a href="<?php echo U('News/index',array('id'=>$id-1));?>">上一篇：<?php echo ($art2['title']); ?></a><?php endif; ?>
                    <?php if(empty($art1)): ?><a>下一篇：没有下一篇</a><?php else: ?><a href="<?php echo U('News/index',array('id'=>$id+1));?>">下一篇：<?php echo ($art1['title']); ?></a><?php endif; ?>
                          
                </div><?php endif; ?>
            </div>
        </div>
        <div>
        </div>
    </div>
   <div class="footer">
        <div class="footer-main cl">
            <div class="yms">友情链接：</div>
            <ul class="cl">
                <?php if(is_array($links)): $i = 0; $__LIST__ = $links;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li>
                        <a href="<?php echo ($vo["link"]); ?>" target="_blank"><?php echo ($vo["title"]); ?></a>
                    </li><?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
            <p class="copy">
                 Copyright  2008 - 2018博友彩票系统（shaove.com.cn）All Rights Reserved
                粤ICP备09063742号 增值电信业务经营许可 电信与信息服务业务经营许可证
            </p >
        </div>
    </div>
</body>

</html>